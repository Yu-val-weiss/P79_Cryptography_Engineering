"""Test suite for Lab 1."""
