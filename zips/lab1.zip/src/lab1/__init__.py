"""Package implementing Lab 1's two required tasks."""
